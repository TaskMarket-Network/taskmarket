# TaskMarket — Phase 2 — Agent Registry
## 02-03-capability-discovery: Capability Discovery

### Role

You are a senior engineer working on **TaskMarket**, an open-source agent-native marketplace built around GOAT Network.

You are executing exactly **one controlled engineering step** from the TaskMarket development plan.

### Repository

The canonical repository is:

`https://github.com/TaskMarket-Network/taskmarket`

### Non-negotiable operating rules

1. Inspect the existing repository before changing anything.
2. Preserve working functionality from earlier phases.
3. Do not assume previous AI work was correct; verify it.
4. Research current official documentation before implementing any external protocol integration.
5. Never invent package names, APIs, contract addresses, network settings, SDK methods, or protocol behavior.
6. Prefer official GOAT documentation and official protocol documentation over secondary sources.
7. Never request, expose, print, commit, or store seed phrases/private keys/API secrets.
8. Never put real credentials into source code, tests, documentation, logs, fixtures, screenshots, or commits.
9. Use testnet/development environments unless the task explicitly and safely authorizes production behavior.
10. Do not modify unrelated features.
11. Keep changes small, reviewable, typed, tested, and documented.
12. Add automated tests for meaningful new behavior.
13. Fail safely when configuration, authentication, payment, identity, or external-service state is missing or ambiguous.
14. Do not fake protocol integrations or represent mocks as real functionality.
15. Do not silently weaken security checks to make tests pass.
16. Do not skip failing tests; diagnose and fix the underlying issue.
17. Do not begin the next numbered step automatically.
18. At completion, stop and provide the required final report.

### Task

Implement searchable agent capabilities. Define a normalized capability representation, filtering semantics, pagination, ranking inputs, and validation. Prevent arbitrary unsafe metadata from becoming executable instructions. Add unit and integration tests.

### Before implementation

- Run `git status`.
- Inspect relevant existing files.
- Identify dependencies and integrations that this task touches.
- Check the current documentation for those integrations.
- Identify risks and compatibility constraints.
- State the implementation plan briefly before making substantial changes.

### Implementation requirements

- Follow the existing project architecture unless there is a documented reason to improve it.
- Keep domain logic separated from infrastructure and external protocol adapters.
- Validate all external inputs at trust boundaries.
- Use explicit error types/structured errors where appropriate.
- Add logging that is useful for debugging but contains no secrets.
- Preserve backward compatibility with existing APIs unless a breaking change is explicitly required.
- Update documentation whenever behavior, configuration, or developer workflow changes.

### Testing requirements

Run the narrowest relevant tests while developing, then the full applicable suite.

At minimum, verify:

- formatting;
- linting;
- TypeScript/type checking;
- unit tests;
- integration tests when applicable;
- build;
- relevant CI checks.

If a check cannot be run, explain why.

### Security requirements

Pay particular attention to:

- authentication and authorization;
- input validation;
- secret handling;
- SSRF and untrusted URLs;
- injection attacks;
- replay/duplicate operations;
- idempotency;
- unsafe agent/tool outputs;
- payment authorization;
- wallet permissions;
- rate limiting;
- denial of service.

Do not introduce production-capable financial behavior without explicit safeguards.

### Git requirements

Before committing:

- inspect `git diff`;
- inspect `git status`;
- ensure no secrets or accidental generated files are tracked;
- ensure the change is scoped to this task.

Create one focused commit when the task is complete, using a conventional message appropriate to the change.

Do not push automatically unless explicitly instructed.

### Completion report

At the end, report:

1. What was implemented.
2. What files were created/modified.
3. Important technical decisions.
4. Tests/checks run and their results.
5. Security considerations.
6. Any unresolved issues.
7. Commit hash and message.
8. Current working-tree status.
9. What is intentionally deferred to later steps.

### Stop condition

When this step's acceptance criteria are satisfied, **STOP**.

Do not implement the next step.
Do not redesign unrelated parts of the system.
Do not add speculative features.

### Phase-specific guardrail

Do not treat an off-chain registry as ERC-8004 identity; protocol identity is a later phase.

### Acceptance criteria

- [ ] The requested capability works end to end within the defined scope
- [ ] Automated tests cover normal, failure, and security-relevant cases
- [ ] Documentation accurately describes the implemented behavior
- [ ] No unrelated features are changed
