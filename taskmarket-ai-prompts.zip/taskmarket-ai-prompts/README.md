# TaskMarket AI Development Prompts

This directory contains the complete, sequential AI engineering prompt system for building TaskMarket.

Canonical product repository:
https://github.com/TaskMarket-Network/taskmarket

These prompt files are intentionally kept OUTSIDE the TaskMarket product repository.

## Rules

- Give one prompt to the coding AI at a time.
- Run the AI from the TaskMarket repository.
- Do not skip steps.
- After each step, inspect the AI's report, diff, tests, and commit.
- If a step fails, fix that step before continuing.
- Protocol-specific steps must re-check current official documentation.
- Never provide private keys or seed phrases to the coding AI.
- Use testnet/development environments until an explicit production gate.

## Phase map

- Phase 00 — Foundation
- Phase 01 — GOAT Agent Foundation
- Phase 02 — Agent Registry
- Phase 03 — Agent Marketplace
- Phase 04 — Task Engine
- Phase 05 — x402 Payments
- Phase 06 — ERC-8004 Identity
- Phase 07 — Reputation
- Phase 08 — Agent-to-Agent Economy
- Phase 09 — Security, Abuse Resistance & Spending Controls
- Phase 10 — Productionization
- Phase 11 — Deployment
- Phase 12 — Real-World Validation
- Phase 13 — GOAT Builder Program Submission

## Important

The prompts are a development plan, not permission to deploy real money or production infrastructure. Human approval is required for production credentials, mainnet spending, irreversible infrastructure changes, and grant submission.
